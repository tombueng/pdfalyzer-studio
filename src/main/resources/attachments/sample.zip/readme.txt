PDF attachment payload for tests.
